package mb.game.entities;

import mb.game.level.Level;
import mb.game.level.tiles.Tile;

public abstract class Mob extends Entity {

	protected String name;
	protected int speed;
	protected int numSteps = 0;
	protected int prevNumSteps = 0;
	protected boolean isMoving;
	protected int movingDir = 1;
	protected int scale = 1;

	public Mob(Level level, String name, int x, int y, int speed) {
		super(level);
		this.name = name;
		this.x = x;
		this.y = y;
		this.speed = speed;
	}

	public void move(int xa, int ya) {
		// check for no movement on either axis
		if (xa == 0 && ya == 0) {
			isMoving = false;
			return;
		}
		// check for movement on BOTH axes
		// split up movement
		if (xa != 0 && ya != 0) {
			if (!hasCollided(xa, ya)) {
				// SPLITTING MOVEMENT
				// Movement has been detected on both axes
				// processing movement along each axis individually
				isMoving = true;
				move(xa, 0);
				move(0, ya);
				// calling move twice will cause +2 steps when only 1 is taken
				numSteps--;
				return;
			} else {
				// COLLISION DETECTED
				isMoving = false;
				return;
			}
		}
		// code only reaches here with movement on one axis
		prevNumSteps = numSteps;
		numSteps++;// this is currently counting every pixel as a step
		// System.out.println(" current step: #"+ numSteps +" previous step: #"+
		// prevNumSteps);
		if (!hasCollided(xa, ya)) {
			if (ya < 0)
				movingDir = 0;
			if (ya > 0)
				movingDir = 1;
			if (xa < 0)
				movingDir = 2;
			if (xa > 0)
				movingDir = 3;
			// The following checks aren't perfect, but work for now
			// check xMin - check xMax - if ok add movement
			x = (x < 0) ? x = 0 : ((x > level.width * 8) ? x = level.width * 8 : x + xa * speed);
			// same for y
			y = (y < 0) ? y = 0 : ((y > level.height * 8) ? y = level.height * 8 : y + ya * speed);
		}

	}

	public abstract boolean hasCollided(int xa, int ya);

	protected boolean isSolidTile(int xa, int ya, int x, int y) {
		if (level == null) { return false; }
		Tile lastTile = level.getTile((this.x + x) >> 3, (this.y + y) >> 3);
		Tile newTile = level.getTile((this.x + x + xa) >> 3, (this.y + y + ya) >> 3);
		if (!lastTile.equals(newTile) && newTile.isSolid()){
			return true;
		}
		return false;
	}

	public String getName() {
		return name;
	}

}
